Service Boundaries & Responsibilities
API Gateway (Go)
Boundary: External world ↔ Internal services

Single entry point for all client requests
HTTP/HTTPS routing to backend services
WebSocket connection management
Rate limiting & DDoS protection
Request/response validation
CORS & security headers
SSL/TLS termination
DOES NOT: Business logic, data persistence

Security Controls:

Input sanitization (SQLi, XSS, SSRF prevention)
CSRF token validation
Request size limits
HTTP request smuggling defense
WebSocket origin validation


Auth Service (Go)
Boundary: Identity & Access Management

User authentication (JWT-based)
Authorization & RBAC
API key management
Session management
Token issuance & validation
Zero-trust service-to-service auth
DOES NOT: User profile management, scan operations

Security Controls:

Bcrypt password hashing
JWT with short expiry + refresh tokens
Rate limiting on login endpoints
Account lockout after failed attempts
Secure token storage (HttpOnly, Secure flags)


Orchestrator Service (Go)
Boundary: Workflow & Task Coordination

Scan workflow orchestration
Task distribution via Redis Streams
Job scheduling & prioritization
Real-time progress tracking
Retry logic & dead-letter handling
DOES NOT: Actual scanning, report generation

Security Controls:

IDOR prevention (verify ownership)
Task payload validation
Resource quotas per user/org


Workers (Rust)
Boundary: Scan Execution Layer

Each worker consumes tasks from Redis Streams
Executes specific reconnaissance operations
Publishes results back to Redis
Horizontally scalable
DOES NOT: Orchestration, user management

Workers:

Subdomain Worker: DNS enumeration, brute-force, certificate transparency
Port Worker: TCP/UDP scanning, service detection
Vulnerability Worker: CVE checks, misconfigurations, exposed services
Screenshot Worker: Headless browser captures
Tech Detection Worker: Wappalyzer-style fingerprinting

Security Controls:

SSRF protection (whitelist/blacklist)
Timeout & resource limits
Sandboxed execution (containers)
Prevent scanning internal networks


AI Engine (Rust)
Boundary: Intelligence & Risk Analysis

Vulnerability risk scoring
Attack path prediction
Anomaly detection
Contextual recommendations
DOES NOT: Direct scanning, report formatting


Report Service (Rust)
Boundary: Report Generation & Export

PDF, JSON, CSV, HTML exports
Template rendering
Data aggregation from PostgreSQL
Scheduled reports
DOES NOT: Real-time scanning updates

Security Controls:

Path traversal prevention (LFI)
Template injection defense
Sanitize user inputs in reports


Notification Service (Go)
Boundary: External Integrations

Email, Slack, Discord, Webhooks
Alert triggers (critical vulns, scan completion)
Retry logic for failed deliveries
DOES NOT: Business logic, data storage


Shared Libraries (libs/)
go-common

Database connections (PostgreSQL)
Redis queue abstraction
Logger (structured logging)
Error handling
Middleware (auth, CORS, rate limit)
Security utilities (CSRF, sanitization, header hardening)

rust-common

Database pool management
Redis Streams consumer/producer
Logging & tracing
Error types
Security utilities


Communication Patterns
Synchronous (HTTP/gRPC)

Client → API Gateway
API Gateway → Auth Service (token validation)
Services → PostgreSQL (queries)

Asynchronous (Redis Streams)

Orchestrator → Workers (task dispatch)
Workers → AI Engine (results for analysis)
Workers → Report Service (scan data)
Services → Notification Service (events)

Real-time (WebSocket)

API Gateway ↔ Client (scan progress, live updates)


Zero Trust Architecture
Service-to-Service Auth

Each service has a unique API key/JWT
API Gateway validates client tokens via Auth Service
Internal services validate origin headers
No implicit trust between services

Network Segmentation

Workers isolated in separate subnets
Database accessible only via private network
Redis protected with AUTH + encryption


Data Flow Example

User initiates scan → API Gateway
API Gateway validates JWT → Auth Service
API Gateway forwards to Orchestrator
Orchestrator creates tasks → Redis Streams
Workers consume tasks → Execute scans
Workers publish results → Redis Streams
AI Engine processes results → Risk scores
Report Service aggregates data → PostgreSQL
Orchestrator pushes updates → WebSocket (via API Gateway)
User receives real-time progress


Security Checklist (Enforced in All Services)

 Input validation (whitelist approach)
 Output encoding (prevent XSS)
 Parameterized queries (prevent SQLi)
 SSRF protection (URL validation)
 CSRF tokens (state-changing operations)
 IDOR checks (verify resource ownership)
 Rate limiting (per IP, per user)
 Secure headers (HSTS, CSP, X-Frame-Options)
 Secrets in env vars (never hardcoded)
 TLS everywhere (in-transit encryption)


Next Steps

Initialize Go modules in each Go service
Initialize Cargo workspaces for Rust services
Set up shared libraries (go-common, rust-common)
Define API contracts (OpenAPI, Protocol Buffers)
Implement CI/CD pipelines (.github/workflows)
Write service README for each microservice (purpose, API, env vars)
Set up local dev environment (docker-compose)


Golden Rule: Each service owns its data. No direct DB access across services. Communicate via APIs or events.
