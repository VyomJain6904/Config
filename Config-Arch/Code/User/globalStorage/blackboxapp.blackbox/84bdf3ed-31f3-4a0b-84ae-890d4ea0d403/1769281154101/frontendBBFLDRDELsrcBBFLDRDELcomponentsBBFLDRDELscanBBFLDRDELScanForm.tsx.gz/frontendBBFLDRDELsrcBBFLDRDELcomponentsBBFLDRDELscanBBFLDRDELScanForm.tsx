"use client";
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import {
	IconBrandGithub,
	IconBrandGoogle,
	IconBrandOnlyfans,
} from "@tabler/icons-react";

export function AccessForm() {
	const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
		e.preventDefault();
		console.log("Form submitted");
	};
	return (
		<div className="shadow-input mx-auto w-full max-w-md rounded-none md:rounded-2xl p-4 md:p-8 bg-card border border-border">
			<h2 className="text-xl font-bold text-foreground">
				FindIt Access
			</h2>
			<p className="mt-2 max-w-sm text-sm text-muted-foreground">
				Enter your credentials to access the reconnaissance dashboard.
			</p>

			<form className="my-8" onSubmit={handleSubmit}>
				<div className="mb-4 flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2">
					<LabelInputContainer>
						<Label htmlFor="firstname" className="text-foreground">First name</Label>
						<Input id="firstname" placeholder="John" type="text" className="text-foreground" />
					</LabelInputContainer>
					<LabelInputContainer>
						<Label htmlFor="lastname" className="text-foreground">Last name</Label>
						<Input id="lastname" placeholder="Doe" type="text" className="text-foreground" />
					</LabelInputContainer>
				</div>
				<LabelInputContainer className="mb-4">
					<Label htmlFor="email">Email Address</Label>
					<Input
						id="email"
						placeholder="analyst@findit.sec"
						type="email"
						className="text-foreground"
					/>
				</LabelInputContainer>
				<LabelInputContainer className="mb-4">
					<Label htmlFor="password">Password</Label>
					<Input
						id="password"
						placeholder="••••••••"
						type="password"
						className="text-foreground"
					/>
				</LabelInputContainer>
				<LabelInputContainer className="mb-8">
					<Label htmlFor="twitterpassword">
						API Key / Token
					</Label>
					<Input
						id="twitterpassword"
						placeholder="••••••••"
						type="password"
						className="text-foreground"
					/>
				</LabelInputContainer>

				<button
					className="group/btn relative block h-10 w-full rounded-md font-medium text-primary-foreground bg-primary hover:bg-primary/90 shadow-[0px_1px_0px_0px_var(--primary)_inset,0px_-1px_0px_0px_var(--primary)_inset]"
					type="submit"
				>
					Sign up &rarr;
					<BottomGradient />
				</button>

				<div className="my-8 h-[1px] w-full bg-gradient-to-r from-transparent via-border to-transparent" />

				<div className="flex flex-col space-y-4">
					<button
						className="group/btn shadow-input relative flex h-10 w-full items-center justify-start space-x-2 rounded-md px-4 font-medium text-foreground bg-muted hover:bg-muted/80"
						type="submit"
					>
						<IconBrandGithub className="h-4 w-4 text-neutral-800 dark:text-neutral-300" />
						<span className="text-sm text-muted-foreground">
							GitHub
						</span>
						<BottomGradient />
					</button>
					<button
						className="group/btn shadow-input relative flex h-10 w-full items-center justify-start space-x-2 rounded-md px-4 font-medium text-foreground bg-muted hover:bg-muted/80"
						type="submit"
					>
						<IconBrandGoogle className="h-4 w-4 text-neutral-800 dark:text-neutral-300" />
						<span className="text-sm text-muted-foreground">
							Google
						</span>
						<BottomGradient />
					</button>
					<button
						className="group/btn shadow-input relative flex h-10 w-full items-center justify-start space-x-2 rounded-md px-4 font-medium text-foreground bg-muted hover:bg-muted/80"
						type="submit"
					>
						<IconBrandOnlyfans className="h-4 w-4 text-neutral-800 dark:text-neutral-300" />
						<span className="text-sm text-muted-foreground">
							SSO
						</span>
						<BottomGradient />
					</button>
				</div>
			</form>
		</div>
	);
}

const BottomGradient = () => {
	return (
		<>
			<span className="absolute inset-x-0 -bottom-px block h-px w-full bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-0 transition duration-500 group-hover/btn:opacity-100" />
			<span className="absolute inset-x-10 -bottom-px mx-auto block h-px w-1/2 bg-gradient-to-r from-transparent via-indigo-500 to-transparent opacity-0 blur-sm transition duration-500 group-hover/btn:opacity-100" />
		</>
	);
};

const LabelInputContainer = ({
	children,
	className,
}: {
	children: React.ReactNode;
	className?: string;
}) => {
	return (
		<div className={cn("flex w-full flex-col space-y-2", className)}>
			{children}
		</div>
	);
};
