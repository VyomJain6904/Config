"use client";
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import {
	IconBrandGithub,
	IconBrandGoogle,
} from "@tabler/icons-react";

export function RegisterForm() {
	const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
		e.preventDefault();
		console.log("Form submitted");
	};
	return (
		<div className="shadow-input mx-auto w-full max-w-md rounded-none md:rounded-2xl p-4 md:p-8 bg-card">
			<h2 className="text-3xl font-bold text-foreground text-center">
				Sign Up
			</h2>
			<form className="my-8" onSubmit={handleSubmit}>
				<div className="flex flex-row gap-4 mb-4">
					<LabelInputContainer className="flex-1">
						<Label
							htmlFor="firstname"
							className="text-base font-medium"
						>
							First Name
						</Label>
						<Input
							id="firstname"
							placeholder="Admin"
							type="text"
							className="text-foreground h-11 text-base"
						/>
					</LabelInputContainer>
					<LabelInputContainer className="flex-1">
						<Label htmlFor="lastname" className="text-base font-medium">
							Last Name
						</Label>
						<Input
							id="lastname"
							placeholder="Findit"
							type="text"
							className="text-foreground h-11 text-base"
						/>
					</LabelInputContainer>
				</div>
				<LabelInputContainer className="mb-4">
					<Label htmlFor="email" className="text-base font-medium">
						Email Address
					</Label>
					<Input
						id="email"
						placeholder="admin@findit.sec"
						type="email"
						className="text-foreground h-11 text-base"
					/>
				</LabelInputContainer>
				<div className="flex flex-row gap-4 mb-4">
					<LabelInputContainer className="flex-1">
						<Label htmlFor="password" className="text-base font-medium">
							Password
						</Label>
						<Input
							id="password"
							placeholder="••••••••"
							type="password"
							className="text-foreground h-11 text-base"
						/>
					</LabelInputContainer>
				</div>

				<button
					className="group/btn relative block h-10 w-full rounded-xl font-medium text-white bg-zinc-800 from-zinc-900 to-zinc-900 shadow-[0px_1px_0px_0px_#27272a_inset,0px_-1px_0px_0px_#27272a_inset] cursor-pointer"
					type="submit"
				>
					Sign up &rarr;
					<BottomGradient />
				</button>

				<div className="my-8 h-[1px] w-full bg-gradient-to-r from-transparent via-border to-transparent" />

				<div className="flex flex-row justify-center gap-4 mt-6">
					<SocialButton
						icon={<IconBrandGithub className="h-5 w-5" />}
					/>
					<SocialButton
						icon={<IconBrandGoogle className="h-5 w-5" />}
					/>
				</div>

				<p className="mt-6 text-center text-sm text-muted-foreground">
					Already have an account?{" "}
					<a
						href="/login"
						className="text-[#ff79c6] hover:text-[#ff79c6]/80 font-medium transition-colors"
					>
						Sign in
					</a>
				</p>
			</form>
		</div>
	);
}

const BottomGradient = () => {
	return (
		<>
			<span className="absolute inset-x-0 -bottom-px block h-px w-full bg-gradient-to-r from-transparent via-[#ff79c6] to-transparent opacity-0 transition duration-500 group-hover/btn:opacity-100" />
			<span className="absolute inset-x-10 -bottom-px mx-auto block h-px w-1/2 bg-gradient-to-r from-transparent via-[#ff79c6] to-transparent opacity-0 blur-sm transition duration-500 group-hover/btn:opacity-100" />
		</>
	);
};

const SocialButton = ({ icon }: { icon: React.ReactNode }) => (
	<button
		className="group/btn relative flex h-12 w-12 items-center justify-center rounded-full bg-transparent hover:bg-[#6272a4]/30 border border-[#6272a4]/50 transition-all duration-300"
		type="submit"
	>
		<span className="text-neutral-300 group-hover/btn:text-white transition-colors">
			{icon}
		</span>
	</button>
);

const LabelInputContainer = ({
	children,
	className,
}: {
	children: React.ReactNode;
	className?: string;
}) => {
	return (
		<div className={cn("flex w-full flex-col space-y-2", className)}>
			{children}
		</div>
	);
};

const Page = () => {
	return (
		<div className="min-h-screen flex items-center justify-center bg-background">
			<RegisterForm />
		</div>
	);
};

export default Page;
