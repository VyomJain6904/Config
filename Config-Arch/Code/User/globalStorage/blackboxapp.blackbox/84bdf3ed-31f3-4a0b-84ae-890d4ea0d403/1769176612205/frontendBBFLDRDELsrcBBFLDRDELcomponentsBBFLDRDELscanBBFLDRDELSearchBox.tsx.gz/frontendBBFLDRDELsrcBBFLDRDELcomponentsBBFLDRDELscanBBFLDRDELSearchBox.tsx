"use client";

import React from "react";

import { Button } from "@/components/magic/MovingBorder";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export function SearchDomainBox() {
	const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
		e.preventDefault();
		console.log("Form submitted");
	};
	return (
		<div className="shadow-input mx-auto w-full max-w-md rounded-xl p-2 md:rounded-2xl bg-card border-2 border-[#ff79c6]">
			<form className="my-4" onSubmit={handleSubmit}>
				<LabelInputContainer className="mb-4 text-xl text-foreground">
					<Label
						htmlFor="domain"
						className="text-center text-xl text-foreground"
					>
						Search Domain
					</Label>
					<Input
						id="domain"
						useAnimatedPlaceholder={true}
						type="domain"
					/>
				</LabelInputContainer>
				<Button
					onClick={() => console.log("Search button clicked")}
					borderRadius="10rem"
					className="w-full bg-[#ff79c6] text-black text-sm sm:text-base md:text-lg px-4 py-2 sm:px-6 sm:py-2 hover:bg-[#ff79c6]/80 transition-colors duration-200 cursor-pointer"
				>
					Search &rarr;
				</Button>
			</form>
		</div>
	);
}

const LabelInputContainer = ({
	children,
	className,
}: {
	children: React.ReactNode;
	className?: string;
}) => {
	return (
		<div className={cn("flex w-full flex-col space-y-2", className)}>
			{children}
		</div>
	);
};
