"use client";
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import {
	IconBrandGithub,
	IconBrandGoogle,
	IconBrandOnlyfans,
} from "@tabler/icons-react";

export function LoginForm() {
	const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
		e.preventDefault();
		console.log("Form submitted");
	};
	return (
		<div className="shadow-input mx-auto w-full max-w-md rounded-none md:rounded-2xl p-4 md:p-8 bg-card">
			<h2 className="text-2xl font-bold text-foreground text-center">
				Login
			</h2>
			<form className="my-8" onSubmit={handleSubmit}>
				<LabelInputContainer className="mb-4">
					<Label htmlFor="email">Email Address</Label>
					<Input
						id="email"
						placeholder="analyst@findit.sec"
						type="email"
						className="text-foreground"
					/>
				</LabelInputContainer>
				<LabelInputContainer className="mb-6">
					<Label htmlFor="password">Password</Label>
					<Input
						id="password"
						placeholder="••••••••"
						type="password"
						className="text-foreground"
					/>
				</LabelInputContainer>

				<button
					className="group/btn relative block h-10 w-full rounded-xl font-medium text-white bg-zinc-800 from-zinc-900 to-zinc-900 shadow-[0px_1px_0px_0px_#27272a_inset,0px_-1px_0px_0px_#27272a_inset] cursor-pointer"
					type="submit"
				>
					Search &rarr;
					<BottomGradient />
				</button>

				<div className="my-8 h-[1px] w-full bg-gradient-to-r from-transparent via-border to-transparent" />

				<div className="flex flex-col space-y-3">
					<SocialButton
						icon={<IconBrandGithub className="h-4 w-4" />}
						label="GitHub"
					/>
					<SocialButton
						icon={<IconBrandGoogle className="h-4 w-4" />}
						label="Google"
					/>
					<SocialButton
						icon={<IconBrandOnlyfans className="h-4 w-4" />}
						label="SSO"
					/>
				</div>
			</form>
		</div>
	);
}

const BottomGradient = () => {
	return (
		<>
			<span className="absolute inset-x-0 -bottom-px block h-px w-full bg-gradient-to-r from-transparent via-[#ff79c6] to-transparent opacity-0 transition duration-500 group-hover/btn:opacity-100" />
			<span className="absolute inset-x-10 -bottom-px mx-auto block h-px w-1/2 bg-gradient-to-r from-transparent via-[#ff79c6] to-transparent opacity-0 blur-sm transition duration-500 group-hover/btn:opacity-100" />
		</>
	);
};

const SocialButton = ({ icon, label }: { icon: React.ReactNode; label: string }) => (
	<button
		className="group/btn shadow-input relative flex h-10 w-full items-center justify-start space-x-2 rounded-md px-4 font-medium text-foreground bg-[#44475a] hover:bg-[#6272a4] border border-[#6272a4] transition-colors duration-300"
		type="submit"
	>
		<span className="text-neutral-800 dark:text-neutral-300 group-hover/btn:text-white transition-colors">
			{icon}
		</span>
		<span className="text-sm text-muted-foreground group-hover/btn:text-foreground transition-colors">
			{label}
		</span>
		<SocialBottomGradient />
	</button>
);

const SocialBottomGradient = () => {
	return (
		<>
			<span className="absolute inset-x-0 -bottom-px block h-px w-full bg-gradient-to-r from-transparent via-[#ff79c6] to-transparent opacity-0 transition duration-500 group-hover/btn:opacity-100" />
			<span className="absolute inset-x-10 -bottom-px mx-auto block h-px w-1/2 bg-gradient-to-r from-transparent via-[#ff79c6] to-transparent opacity-0 blur-sm transition duration-500 group-hover/btn:opacity-100" />
		</>
	);
};

const LabelInputContainer = ({
	children,
	className,
}: {
	children: React.ReactNode;
	className?: string;
}) => {
	return (
		<div className={cn("flex w-full flex-col space-y-2", className)}>
			{children}
		</div>
	);
};

const Page = () => {
	return (
		<div className="min-h-screen flex items-center justify-center bg-background">
			<LoginForm />
		</div>
	);
};

export default Page;
