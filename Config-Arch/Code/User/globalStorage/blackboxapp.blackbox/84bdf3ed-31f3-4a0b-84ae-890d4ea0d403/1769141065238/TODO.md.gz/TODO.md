# Theme Update: Gold/Amber to Dracula Pink

## Summary
Replaced all gold and amber theme colors with Dracula pink (#ff79c6) across the frontend application.

## Files Updated

### ✅ Completed
- [x] `frontend/src/components/dashboardPageUI/moving-border.tsx`
  - Replaced `#FFD700` with `#ff79c6` in radial gradient
  - Replaced `yellow-950` with `#ff79c6` in border and background

- [x] `frontend/src/components/scan/CheckboxList.tsx`
  - Renamed `GoldSwitch` to `PinkSwitch`
  - Replaced `#FFD700` with `#ff79c6` for switch colors

- [x] `frontend/src/components/ui/customError.tsx`
  - Replaced amber gradient (`from-amber-300 via-yellow-400 to-amber-6`) with `#ff79c6` pink gradient

- [x] `frontend/src/components/ui/animated-tooltip.tsx`
  - Replaced `amber-400` with `#ff79c6` in tooltip border gradients

## Dracula Pink Color Used
- Primary: `#ff79c6` (Dracula Pink)

## Status
✅ All theme updates completed successfully

