"use client";

import React from "react";

import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { SearchButton } from "./ScanButton";

export function SearchDomainBox() {
    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        console.log("Form submitted");
    };
    return (
        <div className="shadow-input mx-auto w-full max-w-md rounded-xl p-2 md:rounded-2xl bg-card border border-border">
            <form className="my-4" onSubmit={handleSubmit}>
                <LabelInputContainer className="mb-4 text-xl text-foreground">
                    <Label htmlFor="domain" className="text-center text-xl text-foreground">
                        Search Domain
                    </Label>
                    <Input
                        id="domain"
                        useAnimatedPlaceholder={true}
                        type="domain"
                    />
                </LabelInputContainer>
                <SearchButton
                    Search &rarr;
                    <BottomGradient />
                />
            </form>
        </div>
    );
}

const BottomGradient = () => {
    return (
        <>
            <span className="absolute inset-x-0 -bottom-px block h-px w-full bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-0 transition duration-500 group-hover/btn:opacity-100" />
            <span className="absolute inset-x-10 -bottom-px mx-auto block h-px w-1/2 bg-gradient-to-r from-transparent via-purple-500 to-transparent opacity-0 blur-sm transition duration-500 group-hover/btn:opacity-100" />
        </>
    );
};

const LabelInputContainer = ({
    children,
    className,
}: {
    children: React.ReactNode;
    className?: string;
}) => {
    return (
        <div className={cn("flex w-full flex-col space-y-2", className)}>
            {children}
        </div>
    );
};
