import { LoginButton } from "@/components/layout/LoginButton";
import { MovingGlobe } from "@/components/aceternity/MovingGlobe";
import { SearchDomainBox } from "@/components/scan/SearchBox";
import { GridBackground } from "@/components/ui/gridBackground";
import { Tooltip } from "@/components/toolTip";
import CustomSpotlightCard from "@/components/aceternity/SpotlightCard";
import { Dock } from "@/components/layout/Dock";
import { Banner } from "@/components/layout/Banner";

export default function Home() {
	return (
		<div className="relative min-h-screen bg-background text-foreground overflow-hidden">
            <Banner />
            <Dock />
			<LoginButton />
			<div className="flex flex-col items-center justify-start space-y-12 px-4 pt-10 pb-20">
				<MovingGlobe />
				<SearchDomainBox />
				<CustomSpotlightCard />
				<GridBackground />
				<Tooltip />
			</div>
		</div>
	);
}
