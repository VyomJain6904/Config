"use client";

import React from "react";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/moving-border";

export function LoginButton() {
	const { isAuthenticated, user, logout } = useAuth();

	if (isAuthenticated) {
		return (
			<div className="fixed top-4 right-4 z-50 sm:top-6 sm:right-6 flex items-center space-x-3">
				{/* User Avatar */}
				<Link href="/dashboard" className="flex items-center space-x-2">
					{user?.avatar_url ? (
						<img src={user.avatar_url} alt="" className="w-8 h-8 rounded-full border border-amber-500" />
					) : (
						<div className="w-8 h-8 rounded-full bg-amber-500 flex items-center justify-center text-black font-bold text-sm">
							{user?.name?.[0]?.toUpperCase() || user?.email?.[0]?.toUpperCase() || "U"}
						</div>
					)}
					<span className="hidden sm:inline text-white text-sm">{user?.name || "Dashboard"}</span>
				</Link>

				<Button
					onClick={async () => {
						await logout();
						window.location.href = "/";
					}}
					borderRadius="10rem"
					className="bg-black text-white text-sm px-4 py-2 hover:bg-red-500/50 transition-colors duration-200 cursor-pointer"
				>
					Logout
				</Button>
			</div>
		);
	}

	return (
		<div className="fixed top-4 right-4 z-50 sm:top-6 sm:right-6 flex items-center space-x-2">
			<Link href="/login">
				<Button
					borderRadius="10rem"
					className="bg-black text-white text-sm sm:text-base md:text-lg px-4 py-2 sm:px-6 sm:py-2 hover:bg-yellow-500/50 transition-colors duration-200 cursor-pointer"
				>
					Login
				</Button>
			</Link>
		</div>
	);
}
