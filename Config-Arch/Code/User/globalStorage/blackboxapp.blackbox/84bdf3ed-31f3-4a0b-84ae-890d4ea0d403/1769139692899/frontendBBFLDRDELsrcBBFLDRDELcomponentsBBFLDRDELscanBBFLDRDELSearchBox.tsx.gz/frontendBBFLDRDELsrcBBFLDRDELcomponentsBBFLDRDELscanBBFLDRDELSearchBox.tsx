"use client";

import React from "react";

import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export function SearchDomainBox() {
    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        console.log("Form submitted");
    };
    return (
        <div className="shadow-input mx-auto w-full max-w-md rounded-xl p-2 md:rounded-2xl bg-card border border-border">
            <form className="my-4" onSubmit={handleSubmit}>
                <LabelInputContainer className="mb-4 text-xl text-foreground">
                    <Label htmlFor="domain" className="text-center text-xl text-foreground">
                        Search Domain
                    </Label>
                    <Input
                        id="domain"
                        useAnimatedPlaceholder={true}
                        type="domain"
                    />
                </LabelInputContainer>
                <button
                    className="group/btn relative block h-10 w-full rounded-xl font-medium text-white bg-black hover:bg-black/90 shadow-[0px_1px_0px_0px_var(--primary)_inset,0px_-1px_0px_0px_var(--primary)_inset] cursor-pointer"
                    type="submit"
                >
                    Search &rarr;
                    <BottomGradient />
                </button>
            </form>
        </div>
    );
}

const BottomGradient = () => {
    return (
        <>

        </>
    );
};

const LabelInputContainer = ({
    children,
    className,
}: {
    children: React.ReactNode;
    className?: string;
}) => {
    return (
        <div className={cn("flex w-full flex-col space-y-2", className)}>
            {children}
        </div>
    );
};
