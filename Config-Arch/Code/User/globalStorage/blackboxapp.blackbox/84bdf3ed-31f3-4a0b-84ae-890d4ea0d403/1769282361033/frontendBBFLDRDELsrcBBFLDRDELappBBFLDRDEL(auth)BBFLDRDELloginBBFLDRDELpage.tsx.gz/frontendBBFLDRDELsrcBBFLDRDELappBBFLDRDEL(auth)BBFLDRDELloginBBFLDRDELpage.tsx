"use client";
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import {
	IconBrandGithub,
	IconBrandGoogle,
} from "@tabler/icons-react";

export function LoginForm() {
	const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
		e.preventDefault();
		console.log("Form submitted");
	};
	return (
		<div className="shadow-input mx-auto w-full max-w-md rounded-none md:rounded-2xl p-4 md:p-8 bg-card">
			<h2 className="text-3xl font-bold text-foreground text-center">
				Login
			</h2>
			<form className="my-8" onSubmit={handleSubmit}>
				<LabelInputContainer className="mb-6">
					<Label htmlFor="email" className="text-lg font-medium">Email Address</Label>
					<Input
						id="email"
						placeholder="admin@findit.sec"
						type="email"
						className="text-foreground h-12 text-lg"
					/>
				</LabelInputContainer>
				<LabelInputContainer className="mb-8">
					<Label htmlFor="password" className="text-lg font-medium">Password</Label>
					<Input
						id="password"
						placeholder="admin123"
						type="password"
						className="text-foreground h-12 text-lg"
					/>
				</LabelInputContainer>

				<button
					className="group/btn relative block h-10 w-full rounded-xl font-medium text-white bg-zinc-800 from-zinc-900 to-zinc-900 shadow-[0px_1px_0px_0px_#27272a_inset,0px_-1px_0px_0px_#27272a_inset] cursor-pointer"
					type="submit"
				>
					Search &rarr;
					<BottomGradient />
				</button>

				<div className="my-8 h-[1px] w-full bg-gradient-to-r from-transparent via-border to-transparent" />

				<div className="flex flex-row justify-center gap-4 mt-6">
					<SocialButton icon={<IconBrandGithub className="h-5 w-5" />} />
					<SocialButton icon={<IconBrandGoogle className="h-5 w-5" />} />
				</div>

				<p className="mt-6 text-center text-sm text-muted-foreground">
					Don't have an account?{" "}
					<a
						href="/register"
						className="text-[#ff79c6] hover:text-[#ff79c6]/80 font-medium transition-colors"
					>
						Sign up
					</a>
				</p>
			</form>
		</div>
	);
}

const BottomGradient = () => {
	return (
		<>
			<span className="absolute inset-x-0 -bottom-px block h-px w-full bg-gradient-to-r from-transparent via-[#ff79c6] to-transparent opacity-0 transition duration-500 group-hover/btn:opacity-100" />
			<span className="absolute inset-x-10 -bottom-px mx-auto block h-px w-1/2 bg-gradient-to-r from-transparent via-[#ff79c6] to-transparent opacity-0 blur-sm transition duration-500 group-hover/btn:opacity-100" />
		</>
	);
};

const SocialButton = ({ icon }: { icon: React.ReactNode }) => (
	<button
		className="group/btn relative flex h-12 w-12 items-center justify-center rounded-full bg-transparent hover:bg-[#6272a4]/30 border border-[#6272a4]/50 transition-all duration-300"
		type="submit"
	>
		<span className="text-neutral-300 group-hover/btn:text-white transition-colors">
			{icon}
		</span>
	</button>
);

const LabelInputContainer = ({
	children,
	className,
}: {
	children: React.ReactNode;
	className?: string;
}) => {
	return (
		<div className={cn("flex w-full flex-col space-y-2", className)}>
			{children}
		</div>
	);
};

const Page = () => {
	return (
		<div className="min-h-screen flex items-center justify-center bg-background">
			<LoginForm />
		</div>
	);
};

export default Page;
